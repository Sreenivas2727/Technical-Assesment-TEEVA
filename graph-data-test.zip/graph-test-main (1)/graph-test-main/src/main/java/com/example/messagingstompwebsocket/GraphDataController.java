package com.example.messagingstompwebsocket;

import java.time.LocalTime;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.RestController;

import com.example.messagingstompwebsocket.components.GraphData;
import com.fasterxml.jackson.core.JsonProcessingException;

import lombok.extern.log4j.Log4j2;

@RestController
@Log4j2
public class GraphDataController {

    private SimpMessagingTemplate simpMessagingTemplate;
    private GraphData graphData;

    public GraphDataController(SimpMessagingTemplate simpMessagingTemplate, GraphData graphData) {

        this.graphData = graphData;
        this.simpMessagingTemplate = simpMessagingTemplate;
    }

//    @Async
    //@Scheduled(fixedRate = 1000)
    @MessageMapping("/hello")
	@SendTo("/topic/greetings")
    public Greeting sendPeriodicMessages() throws JsonProcessingException {

        String broadcast = String.format("server periodic message %s via the broker", LocalTime.now());
        System.out.println(broadcast);

        
        return new Greeting(this.graphData.getHeadObject());
       	//log.info("sending data : {}", data);

       // simpMessagingTemplate.convertAndSend("/topic/graph_data", data, header);

    }


}