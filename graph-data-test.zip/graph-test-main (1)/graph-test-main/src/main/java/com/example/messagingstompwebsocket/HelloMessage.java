package com.example.messagingstompwebsocket;


//public class HelloMessage {
//
//    private String message;
//
//    public HelloMessage() {
//    }
//
//    public HelloMessage(String message) {
//        this.message = message;
//    }
//
//    public String getMessage() {
//        return message;
//    }
//
//    public void setMessage(String message) {
//        this.message = message;
//    }
//
//}

public class HelloMessage{

    private String epochTime;
    private Object floatValue;

    public HelloMessage() {
    }


    public String getName() {
        return epochTime;
    }

    public void setName(String name) {
        this.epochTime = name;
    }
    
    public Object getvalue() {
        return floatValue;
    }

    public void setvalue(Object str) {
        this.floatValue = str;
    }
    
   @Override
    public String toString() {
        return this.epochTime + " , " + this.floatValue ;
    }

}