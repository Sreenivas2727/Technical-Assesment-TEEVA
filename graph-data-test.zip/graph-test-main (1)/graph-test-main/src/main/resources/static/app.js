var stompClient = null;

function setConnected(connected) {
    $("#connect").prop("disabled", connected);
    $("#disconnect").prop("disabled", !connected);
    if (connected) {
        $("#conversation").show();
    }
    else {
        $("#conversation").hide();
    }
    $("#greetings").html("");
}

function connect() {
    var socket = new SockJS('/ws');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function (frame) {
        setConnected(true);
        console.log('Connected: ' + frame);
        stompClient.subscribe('/topic/greetings', function (sendPeriodicMessages) {
            showGreeting(JSON.parse(sendPeriodicMessages.body).content);
        });
    });
}

function disconnect() {
    if (stompClient !== null) {
        stompClient.disconnect();
    }
    setConnected(false);
    console.log("Disconnected");
}

function sendName() {
	console.log("sending name:" + $("#name").val());
    stompClient.send("/app/hello", {}, JSON.stringify({'name': $("#name").val()}));
//    $("#greetings").append("<tr><td>" + $("#name").val() + "</td></tr>");
}

function showGreeting(message) {
    console.log("message received:" + message);
    $("#greetings").append("<tr><td>" + message + "</td></tr>");
}

function sendResponse(message) {
    stompClient.send("/app/test", {}, JSON.stringify({'name': $("#name").val()}));
}

$(function () {
    $("form").on('submit', function (e) {
        e.preventDefault();
    });
    $( "#connect" ).click(function() { connect(); });
    $( "#disconnect" ).click(function() { disconnect(); });
    $( "#send" ).click(function() { sendName(); });
    $( "#test" ).click(function() { sendResponse(); })
});